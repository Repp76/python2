"""
app/database.py
---------------
Database layer. Seed data hanya dimasukkan SEKALI (first run sahaja).
Selepas itu, semua perubahan admin KEKAL selama-lamanya dalam spectre.db.
"""

import sqlite3, json, os
from flask import g


def get_db(app=None):
    from flask import current_app
    if app is None:
        app = current_app
    if "db" not in g:
        g.db = sqlite3.connect(
            app.config["DATABASE"],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def init_db(app):
    db_path = app.config["DATABASE"]
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    # Check sebelum buka file — kalau DB dah ada, JANGAN seed semula
    first_run = not os.path.exists(db_path)

    with sqlite3.connect(db_path) as con:
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        _create_schema(con)
        if first_run:
            _seed_data(con)
            # Tandakan supaya kita tahu seed dah dibuat
            con.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('seeded','1')")
            con.commit()

    # ── Login system tables (accounts / telegram_config) ────────────────────
    # Additive only — does not touch categories/resources/usage_log/meta.
    from . import accounts as _accounts
    from . import roles as _roles
    from . import ip_locks as _ip_locks
    with sqlite3.connect(db_path) as con:
        con.row_factory = sqlite3.Row
        _accounts.ensure_schema(con)
        _roles.ensure_schema(con)
        _ip_locks.ensure_schema(con)
        _accounts.seed_default_config(con)


def _create_schema(con):
    con.executescript("""
        CREATE TABLE IF NOT EXISTS meta (
            key   TEXT PRIMARY KEY,
            value TEXT
        );

        CREATE TABLE IF NOT EXISTS categories (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            slug        TEXT    NOT NULL UNIQUE,
            description TEXT,
            parent_id   INTEGER REFERENCES categories(id) ON DELETE CASCADE,
            icon        TEXT    DEFAULT 'folder',
            sort_order  INTEGER DEFAULT 0,
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS resources (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            name             TEXT    NOT NULL,
            description      TEXT,
            url              TEXT    NOT NULL,
            category_id      INTEGER NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
            tags             TEXT    DEFAULT '[]',
            status           TEXT    DEFAULT 'active' CHECK(status IN ('active','inactive','unknown')),
            free             INTEGER DEFAULT 1,
            requires_account INTEGER DEFAULT 0,
            added_at         DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at       DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS usage_log (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            resource_id INTEGER REFERENCES resources(id) ON DELETE CASCADE,
            logged_at   DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_cat_parent   ON categories(parent_id);
        CREATE INDEX IF NOT EXISTS idx_res_category ON resources(category_id);
        CREATE INDEX IF NOT EXISTS idx_res_status   ON resources(status);
    """)
    con.commit()


def _seed_data(con):
    def cat(name, slug, desc, parent=None, icon="folder", order=0):
        cur = con.execute(
            "INSERT INTO categories(name,slug,description,parent_id,icon,sort_order) VALUES(?,?,?,?,?,?)",
            (name, slug, desc, parent, icon, order)
        )
        con.commit()
        return cur.lastrowid

    def res(name, desc, url, cid, tags=None, free=1, account=0):
        con.execute(
            "INSERT INTO resources(name,description,url,category_id,tags,free,requires_account) VALUES(?,?,?,?,?,?,?)",
            (name, desc, url, cid, json.dumps(tags or []), free, account)
        )

    # Root categories
    people   = cat("People & Identity",     "people-identity",     "Research individuals through usernames, email, phone, and public records.", icon="user",      order=1)
    domain   = cat("Domain & Network",      "domain-network",      "Investigate domains, IPs, DNS, certificates, and network infrastructure.",  icon="network",   order=2)
    social   = cat("Social Media",          "social-media",        "Analyse social network profiles, posts, and connections.",                  icon="share",     order=3)
    threat   = cat("Threat Intelligence",   "threat-intelligence", "Cybersecurity threat data, malware analysis, breach monitoring.",           icon="shield",    order=4)
    geo      = cat("Geolocation & Maps",    "geo-maps",            "Satellite imagery, geolocation, aviation, maritime, and mapping tools.",    icon="map-pin",   order=5)
    business = cat("Business & Finance",    "business-finance",    "Company research, filings, crypto, and financial intelligence.",            icon="briefcase", order=6)
    media    = cat("Media & Archives",      "media-archives",      "Image research, metadata analysis, document investigation, web archives.",  icon="archive",   order=7)
    gov      = cat("Government & Legal",    "gov-legal",           "Government records, court documents, public registries.",                   icon="landmark",  order=8)
    search   = cat("Search & Discovery",    "search-discovery",    "Search engines, data aggregators, and general discovery tools.",            icon="search",    order=9)
    darkweb  = cat("Dark Web & Monitoring", "dark-web",            "Dark web monitoring and exposure analysis tools.",                          icon="eye-off",   order=10)

    # Sub-categories: People
    username  = cat("Username Research", "username",      "Find accounts across platforms.", parent=people, icon="at-sign", order=1)
    email_c   = cat("Email Research",    "email",         "Investigate email addresses.",    parent=people, icon="mail",    order=2)
    phone_c   = cat("Phone Research",    "phone",         "Reverse phone lookup.",           parent=people, icon="phone",   order=3)
    people_s  = cat("People Search",     "people-search", "Public records people search.",   parent=people, icon="users",   order=4)

    # Sub-categories: Domain & Network
    ip_c     = cat("IP Research",             "ip-research",         "IP geolocation, reputation, WHOIS.", parent=domain, icon="server",    order=1)
    dns_c    = cat("DNS Intelligence",         "dns",                 "DNS records and history.",           parent=domain, icon="git-branch",order=2)
    whois_c  = cat("WHOIS & Registration",     "whois",               "Domain ownership history.",          parent=domain, icon="file-text", order=3)
    cert_c   = cat("Certificate Transparency", "cert-transparency",   "SSL/TLS certificate logs.",          parent=domain, icon="lock",      order=4)
    net_c    = cat("Network Intelligence",     "network-intel",       "BGP, ASN, and routing data.",        parent=domain, icon="activity",  order=5)

    # Sub-categories: Social Media
    sm_an = cat("Profile Analysis", "sm-analysis", "Analyse social media profiles.", parent=social, icon="bar-chart-2", order=1)
    sm_se = cat("Social Search",    "sm-search",   "Cross-platform social search.",  parent=social, icon="search",      order=2)

    # Sub-categories: Threat
    malware  = cat("Malware Analysis",  "malware",          "Sandbox and static analysis.",          parent=threat, icon="bug",            order=1)
    breach_c = cat("Breach Monitoring", "breach",           "Check for credential breaches.",        parent=threat, icon="alert-triangle", order=2)
    url_c    = cat("URL & Link Analysis","url-analysis",    "Analyse suspicious links.",             parent=threat, icon="link",           order=3)
    footprt  = cat("Digital Footprint", "digital-footprint","Assess an organisation's exposure.",    parent=threat, icon="crosshair",      order=4)

    # Sub-categories: Geo
    geo_t  = cat("Geolocation Tools",  "geo-tools", "Geolocate images and objects.", parent=geo, icon="map-pin", order=1)
    avia   = cat("Aviation",           "aviation",  "Aircraft tracking.",            parent=geo, icon="send",    order=2)
    marit  = cat("Maritime",           "maritime",  "Vessel tracking, AIS data.",    parent=geo, icon="anchor",  order=3)
    sat    = cat("Satellite & Imagery","satellite", "Satellite imagery analysis.",   parent=geo, icon="globe",   order=4)

    # Sub-categories: Business
    comp_s = cat("Company Search",  "company-search", "Company registries.",             parent=business, icon="building",    order=1)
    crypto = cat("Cryptocurrency",  "cryptocurrency", "Blockchain analysis.",            parent=business, icon="dollar-sign", order=2)
    vehicl = cat("Vehicle Research","vehicle",        "Vehicle registration and VIN.",   parent=business, icon="truck",       order=3)

    # Sub-categories: Media
    img_c  = cat("Image Research",   "image-research", "Reverse image search.",        parent=media, icon="image",  order=1)
    meta_c = cat("Metadata Analysis","metadata",       "Extract file metadata.",        parent=media, icon="layers", order=2)
    doc_c  = cat("Document Research","document",       "Document intelligence.",        parent=media, icon="file",   order=3)
    arch_c = cat("Web Archives",     "web-archives",   "Historical web snapshots.",     parent=media, icon="clock",  order=4)

    # Sub-categories: Government
    pub_r  = cat("Public Records","public-records","Public record databases.", parent=gov, icon="file-text", order=1)
    court  = cat("Court Records", "court-records", "Judicial documents.",      parent=gov, icon="scale",     order=2)

    # Sub-categories: Search
    se_c   = cat("Search Engines","search-engines","General search engines.",      parent=search, icon="search",   order=1)
    dork_c = cat("Google Dorking","google-dorking","Advanced search techniques.", parent=search, icon="terminal", order=2)

    # ── Resources ────────────────────────────────────────────────────────────────

    # Username
    res("Sherlock",              "Hunt down social media accounts across 400+ platforms by username.",                     "https://github.com/sherlock-project/sherlock",                    username,  ["cli","github","python"])
    res("WhatsMyName",           "Cross-platform username existence checker.",                                              "https://whatsmyname.app",                                         username,  ["web","username"])
    res("Namechk",               "Check username availability across hundreds of social networks.",                         "https://namechk.com",                                             username,  ["web","domain"])
    res("UserSearch.org",        "Search for a username across 2000+ social networks.",                                    "https://usersearch.org",                                          username,  ["web"])
    res("Instant Username Search","Real-time username availability checker across platforms.",                              "https://instantusername.com",                                     username,  ["web","realtime"])

    # Email
    res("Hunter.io",      "Find professional email addresses linked to a domain.",         "https://hunter.io",              email_c, ["email","domain"],  free=0, account=1)
    res("Have I Been Pwned","Check if an email appeared in known data breaches.",          "https://haveibeenpwned.com",     email_c, ["breach","security"])
    res("EmailRep.io",    "Analyse email address reputation and risk scoring.",            "https://emailrep.io",            email_c, ["reputation","api"])
    res("MXToolbox",      "Email header analysis, MX records, and blacklist checks.",      "https://mxtoolbox.com",          email_c, ["mx","dns","headers"])
    res("Epieos",         "Reverse email lookup — find accounts linked to an email.",      "https://epieos.com",             email_c, ["reverse","social"])

    # Phone
    res("NumLookup",   "Free reverse phone lookup with carrier info.",                  "https://www.numlookup.com",                                       phone_c, ["reverse","carrier"])
    res("PhoneInfoga", "Advanced phone number OSINT using public sources.",             "https://github.com/sundowndev/phoneinfoga",                        phone_c, ["cli","github"])
    res("Truecaller",  "Crowd-sourced caller ID database.",                            "https://www.truecaller.com",                                      phone_c, ["caller-id"],   free=0, account=1)
    res("CallerID Test","Identify unknown callers using multiple databases.",           "https://www.calleridtest.com",                                    phone_c, ["caller-id"])

    # People Search
    res("Spokeo",    "People search aggregator — addresses, relatives, social profiles.", "https://www.spokeo.com",   people_s, ["aggregator","us"],   free=0)
    res("Pipl",      "Deep web people search across public records.",                    "https://pipl.com",         people_s, ["deep-web","api"],    free=0, account=1)
    res("FamilyTreeNow","Free genealogy and public records search.",                    "https://www.familytreenow.com", people_s, ["genealogy","free"])
    res("FastPeopleSearch","Reverse phone, address, and people search.",               "https://www.fastpeoplesearch.com", people_s, ["free","us"])

    # IP
    res("Shodan",       "Search engine for internet-connected devices.",              "https://www.shodan.io",          ip_c, ["iot","scanning","api"],       free=0, account=1)
    res("Censys",       "Scan and search global internet hosts and certificates.",    "https://search.censys.io",       ip_c, ["scanning","certificates"],    free=0, account=1)
    res("IPInfo.io",    "IP geolocation, ASN, and abuse contact lookup.",             "https://ipinfo.io",              ip_c, ["geolocation","asn","api"])
    res("AbuseIPDB",    "Community-driven IP abuse reporting database.",              "https://www.abuseipdb.com",      ip_c, ["reputation","abuse"])
    res("GreyNoise",    "Analyse internet background noise and mass scanners.",       "https://viz.greynoise.io",       ip_c, ["noise","threat"],             free=0, account=1)
    res("Hurricane Electric BGP","BGP routing and ASN lookup.",                      "https://bgp.he.net",             ip_c, ["bgp","asn","routing"])

    # DNS
    res("SecurityTrails","Historical DNS records, subdomains, WHOIS history.",       "https://securitytrails.com",     dns_c, ["historical","subdomains"],   free=0, account=1)
    res("DNSdumpster",   "Free domain DNS recon and host enumeration.",              "https://dnsdumpster.com",        dns_c, ["recon","subdomains"])
    res("ViewDNS.info",  "DNS lookup with reverse IP and WHOIS.",                   "https://viewdns.info",           dns_c, ["reverse","lookup"])
    res("Passive DNS (CIRCL)","Passive DNS database from CIRCL CERT.",              "https://www.circl.lu/services/passive-dns/", dns_c, ["passive","historical"])

    # WHOIS
    res("ICANN WHOIS",       "Official ICANN WHOIS lookup.",                         "https://lookup.icann.org",                    whois_c, ["official","domain"])
    res("DomainTools WHOIS", "Advanced WHOIS with history and reverse lookups.",     "https://whois.domaintools.com",               whois_c, ["history","reverse"],   free=0)
    res("ARIN WHOIS",        "ARIN WHOIS for North American IP and ASN data.",       "https://search.arin.net/rdap/",               whois_c, ["arin","ip","asn"])
    res("Whoxy",             "Reverse WHOIS — find domains by email or registrant.", "https://www.whoxy.com",                       whois_c, ["reverse","email"])

    # Cert
    res("crt.sh",       "Search Certificate Transparency logs for subdomains.",    "https://crt.sh",                                           cert_c, ["ssl","subdomains"])
    res("Cert Spotter", "Monitor certificate issuances in real time.",             "https://sslmate.com/certspotter/",                         cert_c, ["monitoring","ssl"],  free=0, account=1)
    res("Facebook CT",  "Facebook's Certificate Transparency monitoring API.",     "https://developers.facebook.com/tools/ct/",                cert_c, ["api","ssl"])

    # Network Intel
    res("Shodan Internetdb","Fast API-accessible IP intelligence.",                "https://internetdb.shodan.io",    net_c, ["api","shodan"])
    res("RIPE NCC",          "European internet registry — IP allocations.",       "https://www.ripe.net",            net_c, ["rir","europe"])
    res("Netcraft",          "Web server, hosting, and site history investigation.","https://sitereport.netcraft.com",net_c, ["hosting","history"])
    res("FOFA",              "Chinese cyberspace asset search engine.",            "https://fofa.info",               net_c, ["scanning","china"],   free=0, account=1)

    # Social Media
    res("Social Searcher","Real-time social media search across all major networks.","https://www.social-searcher.com", sm_se, ["realtime","multi-platform"])
    res("IntelX",          "Search darknet, leaks, paste sites, and social data.", "https://intelx.io",                sm_se, ["leaks","darknet","api"], free=0, account=1)
    res("Twint",           "Advanced Twitter scraping without API.",               "https://github.com/twintproject/twint", sm_an, ["twitter","cli","github"])
    res("OSINTgram",       "Instagram OSINT — extract followers and profile data.", "https://github.com/Datalux/Osintgram",  sm_an, ["instagram","cli"])

    # Malware
    res("VirusTotal",       "Analyse files/URLs with 70+ antivirus engines.",       "https://www.virustotal.com",         malware, ["antivirus","url","api"], account=1)
    res("Any.run",          "Interactive online malware sandbox.",                  "https://app.any.run",                malware, ["sandbox","interactive"],  free=0, account=1)
    res("Hybrid Analysis",  "Free malware analysis powered by Falcon Sandbox.",     "https://www.hybrid-analysis.com",    malware, ["sandbox","crowdstrike"],  account=1)
    res("Joe Sandbox",      "Deep malware analysis with full behavioural reports.", "https://www.joesandbox.com",         malware, ["sandbox","detailed"],     free=0, account=1)
    res("MalwareBazaar",    "Abuse.ch malware sample repository.",                  "https://bazaar.abuse.ch",            malware, ["samples","abuse-ch"])

    # Breach
    res("Have I Been Pwned API","API access to breach data for developers.",       "https://haveibeenpwned.com/API/v3", breach_c, ["api","developer"],   free=0)
    res("DeHashed",             "Advanced search engine for compromised data.",    "https://dehashed.com",             breach_c, ["search","api"],       free=0, account=1)
    res("Snusbase",             "Database breach search engine.",                  "https://snusbase.com",             breach_c, ["database","search"],  free=0, account=1)
    res("LeakPeek",             "Search across leaked database compilations.",     "https://leakpeek.com",             breach_c, ["leaks","search"],     free=0)

    # URL Analysis
    res("URLScan.io",  "Scan websites — screenshots, DOM, requests, technologies.", "https://urlscan.io",             url_c, ["scan","screenshot","api"])
    res("URLhaus",     "Abuse.ch database of malicious URLs.",                      "https://urlhaus.abuse.ch",       url_c, ["malware","abuse-ch","api"])
    res("PhishTank",   "Community anti-phishing — submit and verify phishing URLs.","https://www.phishtank.com",      url_c, ["phishing","community"])
    res("Unshorten.it","Expand shortened URLs to see the final destination safely.","https://unshorten.it",           url_c, ["redirect","expand"])

    # Digital Footprint
    res("SpiderFoot",        "Automated OSINT reconnaissance — attack surface maps.","https://github.com/smicallef/spiderfoot",     footprt, ["automation","cli","github"])
    res("Maltego Community", "Visual link analysis for data relationships.",          "https://www.maltego.com/maltego-community/",  footprt, ["visual","graph"], account=1)
    res("theHarvester",      "Gather emails, subdomains, IPs from public sources.",   "https://github.com/laramies/theHarvester",    footprt, ["cli","github","recon"])
    res("Recon-ng",          "Full-featured web reconnaissance framework.",           "https://github.com/lanmaster53/recon-ng",      footprt, ["framework","cli","github"])

    # Geo Tools
    res("SunCalc",       "Determine time from shadow angles and sun position.",  "https://www.suncalc.org",          geo_t, ["sun","shadow","date"])
    res("What3Words",    "3-word address geolocation with 3m² precision.",       "https://what3words.com",           geo_t, ["address","precise"])
    res("Overpass Turbo","OpenStreetMap data query and extraction tool.",         "https://overpass-turbo.eu",        geo_t, ["osm","openstreetmap"])
    res("GeoTips",       "Community-maintained geolocation hinting resource.",   "https://geotips.net",              geo_t, ["community","tips"])

    # Aviation
    res("FlightAware",    "Live flight tracking and aircraft registration data.", "https://www.flightaware.com",      avia, ["live","history","tracking"])
    res("Flightradar24",  "Real-time flight tracker with ADS-B coverage.",        "https://www.flightradar24.com",    avia, ["realtime","ads-b"])
    res("ADS-B Exchange", "Unfiltered, community-driven ADS-B flight data.",      "https://www.adsbexchange.com",     avia, ["ads-b","unfiltered"])
    res("OpenSky Network","Open-source air traffic surveillance research network.","https://opensky-network.org",     avia, ["research","api"])

    # Maritime
    res("MarineTraffic","Global AIS vessel tracking.",           "https://www.marinetraffic.com",  marit, ["ais","live","vessels"])
    res("VesselFinder", "Free AIS-based vessel tracking.",       "https://www.vesselfinder.com",   marit, ["ais","free"])
    res("FleetMon",     "Track ships, ports, and maritime events.","https://www.fleetmon.com",     marit, ["fleet","ports"])
    res("PortWatch",    "Vessel and port monitoring.",           "https://portwatch.imf.org",      marit, ["ports","imf"])

    # Satellite
    res("Google Earth",    "High-resolution satellite imagery and 3D terrain.",    "https://earth.google.com/web/",          sat, ["satellite","3d","google"])
    res("Sentinel Hub",    "ESA Copernicus satellite data.",                       "https://www.sentinel-hub.com",           sat, ["esa","copernicus"],          free=0, account=1)
    res("NASA Worldview",  "NASA satellite imagery archive.",                      "https://worldview.earthdata.nasa.gov",   sat, ["nasa","archive"])
    res("Planet Explorer", "Sub-daily commercial satellite imagery.",              "https://www.planet.com/explorer/",       sat, ["commercial","sub-daily"],    free=0, account=1)

    # Company
    res("OpenCorporates","World's largest company database — 200M+ companies.",   "https://opencorporates.com",                                      comp_s, ["global","200M"])
    res("Companies House","Official UK company registry.",                        "https://find-and-update.company-information.service.gov.uk",      comp_s, ["uk","official"])
    res("SEC EDGAR",      "US SEC company filings database.",                     "https://www.sec.gov/edgar/",                                      comp_s, ["us","sec","filings"])
    res("GLEIF",          "Global Legal Entity Identifier register.",             "https://search.gleif.org",                                        comp_s, ["lei","global"])

    # Crypto
    res("Blockchain Explorer","Bitcoin blockchain browser.",                      "https://www.blockchain.com/explorer",    crypto, ["bitcoin","blockchain"])
    res("Etherscan",          "Ethereum blockchain explorer.",                    "https://etherscan.io",                   crypto, ["ethereum","erc20","api"])
    res("Chainalysis Reactor","Professional blockchain analytics.",               "https://www.chainalysis.com/chainalysis-reactor/", crypto, ["analytics","compliance"], free=0)
    res("CipherTrace",        "Cryptocurrency AML and blockchain analytics.",     "https://ciphertrace.com",                crypto, ["aml","analytics"],           free=0)
    res("Crystal Blockchain", "Visual crypto transaction tracing.",               "https://crystalblockchain.com",          crypto, ["visual","tracing"],           free=0, account=1)

    # Vehicle
    res("VINCheck (NHTSA)","Free VIN check — recalls and safety ratings.",        "https://www.nhtsa.gov/vehicle",          vehicl, ["vin","nhtsa","us"])
    res("AutoCheck",       "Vehicle history from Experian.",                      "https://www.autocheck.com",              vehicl, ["history","experian","us"],   free=0)
    res("Carfax",          "Vehicle history — accidents, service, ownership.",    "https://www.carfax.com",                 vehicl, ["history","us","canada"],     free=0)

    # Image
    res("Google Images", "Reverse image search from Google.",                    "https://images.google.com",              img_c, ["reverse","google"])
    res("Yandex Images", "Yandex reverse image — often finds faces Google misses.","https://yandex.com/images/",           img_c, ["reverse","yandex","faces"])
    res("PimEyes",       "AI-powered face recognition reverse image search.",    "https://pimeyes.com",                    img_c, ["ai","face-recognition"],     free=0, account=1)
    res("Forensically",  "Free image forensics — clone detection, ELA.",         "https://29a.ch/photo-forensics/",        img_c, ["forensics","ela"])
    res("FotoForensics", "JPEG error level analysis and metadata extraction.",   "https://fotoforensics.com",              img_c, ["ela","jpeg","metadata"])

    # Metadata
    res("ExifTool",           "Read and write metadata in image/audio/video files.",         "https://exiftool.org",                     meta_c, ["exif","cli","metadata"])
    res("Jeffrey's Exif Viewer","Web-based EXIF extraction and GPS mapper.",                "https://exif.regex.info/exif.cgi",         meta_c, ["exif","gps","web"])
    res("FOCA",               "Metadata from office documents — emails, authors, software.", "https://github.com/ElevenPaths/FOCA",      meta_c, ["documents","github"])
    res("Metagoofil",         "Metadata extractor via Google dork queries.",                "https://github.com/laramies/metagoofil",   meta_c, ["google","dork","cli"])

    # Document
    res("DocumentCloud","Platform for journalists to upload and analyse documents.","https://www.documentcloud.org", doc_c, ["journalism","ocr"])
    res("Scribd",       "Large repository of public documents and books.",         "https://www.scribd.com",         doc_c, ["documents","books"],  free=0, account=1)
    res("IPFS Search",  "Search content on the InterPlanetary File System.",      "https://ipfs-search.com",        doc_c, ["ipfs","decentralised"])

    # Archives
    res("Wayback Machine","Archive.org — 800+ billion saved web pages.",         "https://web.archive.org",         arch_c, ["archive","history"])
    res("CachedView",    "View Google, Bing, and Wayback cached pages.",         "https://cachedview.nl",           arch_c, ["cache","google","bing"])
    res("Archive.ph",    "Save and retrieve persistent snapshots of web pages.", "https://archive.ph",              arch_c, ["snapshot","persistent"])
    res("Memento",       "Cross-archive time travel for historical web pages.",  "https://timetravel.mementoweb.org",arch_c, ["memento","multi-archive"])

    # Public Records
    res("Data.gov",             "US government open data portal.",                    "https://data.gov",                pub_r, ["us","open-data","government"])
    res("FOIA.gov",             "US Freedom of Information Act portal.",              "https://www.foia.gov",            pub_r, ["foia","us","transparency"])
    res("Sunlight Foundation",  "Transparency and open government data tools.",       "https://sunlightfoundation.com",  pub_r, ["transparency","api"])

    # Court Records
    res("PACER",          "US federal court case documents.",              "https://pacer.uscourts.gov",                court, ["us","federal","court"],  free=0, account=1)
    res("CourtListener",  "Free US federal court opinions database.",      "https://www.courtlistener.com",             court, ["free","us","opinions"])
    res("RECAP Archive",  "Crowd-sourced PACER court document repository.","https://www.courtlistener.com/recap/",      court, ["free","recap"])

    # Search Engines
    res("Google Advanced","Refined Google search with filters.",            "https://www.google.com/advanced_search",    se_c,   ["google","advanced"])
    res("Bing",           "Microsoft search — indexes different results.",  "https://www.bing.com",                      se_c,   ["bing","microsoft"])
    res("DuckDuckGo",     "Privacy-respecting search engine.",              "https://duckduckgo.com",                    se_c,   ["privacy"])
    res("Ahmia",          "Search engine for Tor hidden services.",         "https://ahmia.fi",                          se_c,   ["tor","onion","dark-web"])
    res("Startpage",      "Google results with complete anonymity.",        "https://www.startpage.com",                 se_c,   ["privacy","google-proxy"])

    # Google Dorking
    res("Google Hacking DB","Exploit-DB collection of Google dork queries.", "https://www.exploit-db.com/google-hacking-database", dork_c, ["dorks","exploit-db"])
    res("Pentest-Tools Dork","Generate Google dork queries for recon.",      "https://pentest-tools.com/information-gathering/google-hacking", dork_c, ["generator","dorks"], free=0, account=1)

    # Dark Web
    res("DarkOwl",     "Largest commercial darknet intelligence platform.",     "https://www.darkowl.com",                darkweb, ["commercial","darknet"],     free=0, account=1)
    res("OnionScan",   "Scan hidden services for OPSEC failures.",             "https://github.com/s-rah/onionscan",      darkweb, ["scan","tor","github"])
    res("Intelligence X","Search Tor, I2P, and leak sites for data.",         "https://intelx.io",                       darkweb, ["search","tor","leaks","api"], free=0, account=1)
    res("Ahmia Dark",  "Tor hidden service search engine.",                   "https://ahmia.fi",                        darkweb, ["tor","search"])
    res("Dark Web ID", "Dark web credential monitoring for organisations.",    "https://darkwebid.com",                   darkweb, ["monitoring","credentials"],  free=0, account=1)

    con.commit()
